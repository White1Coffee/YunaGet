package nl.yunaget.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import nl.yunaget.client.core.TaskState;
import java.util.*;

/** Legacy entry points remain available; all breaking uses the vanilla client game mode. */
public final class MiningTask {
    private static boolean enabled;
    private static Object world;
    private static BlockPos target;
    private static int ticks, targetTicks;
    private static final Map<BlockPos, Integer> REJECTED = new HashMap<>();
    public static boolean active() { return enabled; }
    public static boolean controlsAttack() { return enabled && !TaskManager.paused && target != null; }
    public static void start(Identifier id, int amount) {
        if (id != null) YunaGetConfig.get.targets.put(id.toString(), amount);
        start(); YunaGetConfig.save();
    }
    public static void start() {
        var mc = Minecraft.getInstance();
        if (mc.player == null || YunaGetConfig.get.targets.isEmpty()) { TaskManager.status = "Kies eerst een itemdoel"; return; }
        enabled = true; world = mc.level; TaskManager.paused = false; ticks = targetTicks = 0;
        REJECTED.clear(); TaskManager.set("Mining", TaskState.SEARCHING, "Blocks zoeken");
    }
    public static void suspend() {
        if (target != null && Minecraft.getInstance().gameMode != null) Minecraft.getInstance().gameMode.stopDestroyBlock();
        target = null; AutoToolManager.restore();
    }
    public static void stop(String reason) {
        suspend(); enabled = false; REJECTED.clear();
        if (!reason.isEmpty() && Minecraft.getInstance().player != null) Minecraft.getInstance().player.sendSystemMessage(Component.literal("[YunaGet] " + reason));
    }
    public static BlockHitResult hit(BlockPos p) {
        var mc = Minecraft.getInstance(); if (mc.player == null || mc.level == null) return null;
        Vec3 eye = mc.player.getEyePosition(), point = Vec3.atCenterOf(p);
        double range = mc.player.blockInteractionRange();
        if (eye.distanceToSqr(point) > range * range || !mc.level.hasChunkAt(p)) return null;
        var ray = mc.level.clip(new ClipContext(eye, point, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, mc.player));
        return ray.getType() == HitResult.Type.BLOCK && ray.getBlockPos().equals(p) ? ray : null;
    }
    public static void aim(Vec3 p) {
        var player = Minecraft.getInstance().player; Vec3 d = p.subtract(player.getEyePosition());
        player.setYRot((float) Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
        player.setXRot((float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x*d.x + d.z*d.z))));
    }
    public static void tick(Minecraft mc) {
        if (!enabled) return;
        if (mc.level != world) { stop(""); return; }
        var c = YunaGetConfig.get; ticks++;
        if (c.stopAtGoal && InventoryTracker.complete()) {
            stop(""); TaskManager.set("Mining", TaskState.COMPLETE, "Alle itemdoelen bereikt"); return;
        }
        if (!InventoryTracker.hasTargetSpace()) {
            suspend(); TaskManager.set("Mining", TaskState.PAUSED, "Inventory vol; maak ruimte of sorteer"); return;
        }
        REJECTED.entrySet().removeIf(e -> e.getValue() < ticks);
        if (ticks % c.miningInterval != 0) return;
        if (target != null && (!TargetManager.matches(mc.level.getBlockState(target)) || hit(target) == null
            || target.equals(mc.player.blockPosition().below()))) suspend();
        if (target == null) {
            if (ticks % Math.max(5, c.miningInterval) != 0) return;
            List<BlockPos> choices = new ArrayList<>();
            int r = Math.min(6, c.searchRadius);
            for (BlockPos p : BlockPos.betweenClosed(mc.player.blockPosition().offset(-r,-r,-r), mc.player.blockPosition().offset(r,r,r))) {
                if (!mc.level.hasChunkAt(p) || p.distSqr(mc.player.blockPosition()) > c.searchRadius*c.searchRadius || REJECTED.containsKey(p)
                    || p.equals(mc.player.blockPosition().below())) continue;
                var state = mc.level.getBlockState(p);
                if (TargetManager.matches(state) && state.getDestroySpeed(mc.level, p) >= 0 && hit(p) != null) choices.add(p.immutable());
            }
            if (c.nearestFirst) choices.sort(Comparator.comparingDouble(p -> mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(p))));
            for (BlockPos p : choices) {
                if (!AutoToolManager.choose(mc.level.getBlockState(p))) { reject(p); continue; }
                target = p; targetTicks = 0; break;
            }
            if (target == null) {
                var known = !c.onlyVisible ? WorldScanner.mining.stream().min(Comparator.comparingDouble(p -> p.distSqr(mc.player.blockPosition()))).orElse(null) : null;
                String text = known != null ? "Bekend doel " + known.toShortString() + "; loop binnen zicht/bereik" : "Wachten op bereikbaar block of geschikt gereedschap";
                TaskManager.set("Mining", TaskState.SEARCHING, text); return;
            }
            var ray = hit(target); aim(ray.getLocation());
            if (!mc.gameMode.startDestroyBlock(target, ray.getDirection())) { reject(target); suspend(); return; }
        } else {
            if (!AutoToolManager.choose(mc.level.getBlockState(target))) { reject(target); suspend(); return; }
            var ray = hit(target); aim(ray.getLocation()); mc.gameMode.continueDestroyBlock(target, ray.getDirection());
        }
        TaskManager.set("Mining", TaskState.INTERACTING, "Mijnen: " + target.toShortString());
        mc.player.swing(InteractionHand.MAIN_HAND, mc.player.getMainHandItem().getAttackAnimation(), true);
        if (++targetTicks * c.miningInterval >= 400) {
            reject(target); suspend(); TaskManager.set("Mining", TaskState.SEARCHING, "Block overgeslagen na timeout");
        }
    }
    private static void reject(BlockPos p) { if (REJECTED.size() >= 256) REJECTED.clear(); REJECTED.put(p.immutable(), ticks + 600); }
}
