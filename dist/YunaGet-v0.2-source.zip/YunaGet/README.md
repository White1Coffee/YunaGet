# YunaGet v0.2 - Fabric-clientmod voor Minecraft Java 26.3

Uitgebreide versie volgens de v0.2-specificatie: Smart Mine Aura, meerdere inventorydoelen, AutoTool, Drop Collector, Ore ESP en chest-sortering met glow en presets. Dit project vervangt de eerdere kleine 0.3-prototypeversie; installeer slechts een YunaGet-JAR tegelijk.

## Installatie en de Fabric Loader-melding

- Minecraft Java **26.3** met **Java 25**.
- Fabric Loader **0.19.5 of nieuwer**.
- Fabric API **0.165.0+26.3 of nieuwer voor 26.3**. De build gebruikt 0.165.0+26.3; 0.165.2+26.3 voldoet ook aan de versie-eis, maar is niet apart in-game getest.
- Plaats `yunaget-0.2.0.jar` in de client-modmap en verwijder/vervang eerdere YunaGet-JARs. Installeer geen sources-JAR.
- Geen servermod, OP of servercommando's nodig. Servers blijven normale interacties valideren en kunnen functies weigeren.

De oude JAR vereiste `fabricloader >=0.20.1`. Zowel de compilatie-afhankelijkheid als de metadata zijn aangepast naar **0.19.5**. Een regressietest controleert dat deze Loader-versie door de verpakte metadata wordt geaccepteerd. Alleen Fabric API wisselen lost de oude YunaGet-eis niet op: vervang ook de oude mod-JAR. Dit wijzigt niet de Loader-eisen van andere mods.

Fabric noemt Loader 0.19.5 in de [officiele aankondiging voor 26.3](https://fabricmc.net/2026/09/15/263.html). Lunar Client zelf is niet als integratieomgeving getest.

## Bediening

Open met **Y** of `/yunagetui`. Stop alle automatisering met `/yunagetstop`, de stopknop of je ingestelde stoptoets. De bestaande clientcommando's en oude keybindnamen blijven beschikbaar. Nieuwe toetsen zijn standaard niet toegewezen.

| Tab | Functies |
| --- | --- |
| Dashboard | Start, pauze/hervat, stop, actuele taak/status en live voortgang per doel |
| Items | Zoek op registry-ID, kies aantal, voeg meerdere doelen toe met + en verwijder ze met - |
| Mining | Zoekradius, interval, zichtbare/gekende zoekdoelen, afstandsprioriteit, stopdoel en AutoTool |
| Collector | Drop Collector, verzamelradius, selectie, veilige navigatie, item-glow/filter |
| ESP | Ore outlines, afstand, kleuren, eigen blocktypes, door-muren-optie en entityoverzicht/glow |
| Storage | Chest Manager, sorteren, chest-glow, presets, filters, prioriteiten en opslagopties |
| Settings | Alle keybinds, opslaan en configuratie opnieuw laden |

Gebruik < en > om tussen pagina's binnen een tab te wisselen. Labels en tekstvelden zijn Nederlands; IDs blijven de echte registry-IDs. Het menu sluit met X of Escape. Voer getallen binnen de getoonde grenzen in; ongeldige invoer wordt gemeld en niet toegepast.

### Items en Smart Mine Aura

1. Zoek een item, kies het doelgetal en klik + bij het resultaat of op Doel toevoegen/bijwerken.
2. Herhaal voor meerdere items. De doelenlijst kan maximaal 128 verschillende IDs bevatten.
3. Start de geselecteerde doelen vanuit Items of Dashboard.
4. Loop zelf naar geschikte blocks. De aura kiest zichtbare passende blocks binnen het normale interactiebereik, standaard met de dichtstbijzijnde eerst.

Het doel is het **totale huidige aantal in de 36 normale inventoryslots**, niet alleen nieuw opgepakte items. Alle stacks tellen mee. Armor, crafting slots, de cursor en offhand tellen niet mee. De tracker wordt iedere clienttick bijgewerkt, ook bij gebruik/verlies van items. Bij bereikt doel stopt de aura als Stop bij inventorydoel aan staat. Bij gebrek aan inventoryruimte wacht hij tot er weer ruimte is.

De miningzoekradius mag groter zijn dan het normale interactiebereik; dat verlengt het miningbereik niet. Wanneer Alleen zichtbare zoekdoelen uit staat, kunnen bekende blocks achter muren een locatiehint opleveren. De aura breekt alleen een block waarvoor de gewone raycast en bereikcontrole slagen. Onbereikbare doelen worden niet aangeklikt. Afgewezen/te trage blocks worden tijdelijk overgeslagen.

Ondersteund zijn block-items, gewone/deepslate-ertsen en enkele bekende drops, bijvoorbeeld diamond -> beide diamond ores, raw_iron -> beide iron ores, cobblestone -> stone/cobblestone. De client kent niet betrouwbaar alle serverloottabellen. Silk Touch, Fortune, aangepaste loot en modded drops kunnen afwijken. Craft-only items worden niet automatisch gemaakt; iron_ingot wordt bijvoorbeeld niet automatisch uit raw_iron gesmolten.

### AutoTool

AutoTool vergelijkt de negen hotbarslots op correcte drops en snelheid, inclusief de vanilla Efficiency-bonus. Gereedschap op of onder de minimale resterende durability wordt overgeslagen. Een lege hand kan worden gekozen waar geen speciaal gereedschap nodig is. Zonder bruikbaar gereedschap wordt het block overgeslagen. Optioneel wordt het oorspronkelijke slot hersteld zodra de miningactie stopt of wordt onderbroken, zolang je het slot niet zelf hebt gewijzigd.

### Collector en normale beweging

De collector zoekt geladen item-entities, standaard alleen de gekozen doelen die nog nodig zijn. Hij probeert de dichtstbijzijnde drop waarvoor inventoryruimte is. Ophalen gebeurt via echte spelerbeweging en normale pickup: geen itemteleportatie of directe inventorymanipulatie.

De navigatie gebruikt een begrensde grond-BFS met maximaal 2048 cellen en 100 uitbreidingen per inputtick. Hij ondersteunt eenvoudige horizontale routes en stappen van hoogstens een block. Er worden geen deuren geopend, blocks geplaatst of blocks voor een pad gebroken. Geen vliegen of teleporteren. Grote doolhoven, ladders, zwemmen, complexe trappen/slabs en onveilige routes kunnen geen pad opleveren.

Met veilige navigatie worden ook de omgeving van lava/water, vuur, cactus, magma, kampvuren, poedersneeuw, bessenstruiken en witherroos vermeden. Gevaar zoals brand, lage gezondheid of een val stopt de navigatie. Dit is een eenvoudige conservatieve planner, geen garantie tegen mobs, explosies of veranderende wereldsituaties.

**Fysiek bewegen, springen of sneaken onderbreekt AutoWalk en pauzeert de automatisering.** Hervat via Dashboard. Een GUI of inactief venster onderbreekt beweging. Wisselen van wereld/dimensie pauzeert de gedeelde taakbesturing. De collector stopt bij alle bereikte itemdoelen wanneer stop-op-doel aan staat.

### Item Glow, Entity Glow en Ore ESP

- Item Glow markeert geladen drops binnen 64 blocks. Kies alle drops of alle ingestelde itemdoelen. Oorspronkelijke Minecraft-glow blijft intact als YunaGet-glow uit staat.
- Entity Glow markeert het gekozen type uit het entityoverzicht binnen de renderafstand. Er is geen aanvalsaura, teleport- of killactie.
- Ore ESP tekent outlines via de Minecraft 26.3-gizmo-extractiepipeline. De standaardlijst bevat diamond, iron, gold, emerald, redstone, lapis, copper en coal, inclusief deepslate, plus ancient debris.
- Voeg eigen block-IDs toe met een kleur van zes hextekens, bijvoorbeeld `55FFFF`. Kleuren zijn per blocktype bewerkbaar.
- Door muren zichtbaar verandert alleen de rendering. Server-side verborgen/anti-xray-gegevens worden niet gereconstrueerd.
- De scan verwerkt maximaal 1024 posities per tick en caches maximaal 2048 ores en 2048 miningdoelen. De renderer tekent maximaal 512 ore-outlines per frame. Scans gebruiken alleen geladen chunkgegevens. Blockupdates verwijderen cacheposities; chunkunloads en wereldwissels wissen de cache. Bij grote radius kan een volledige scan meerdere seconden duren.

## Chest Manager, glow en presets

### Markeren en deselecteren

1. Open Storage en kies **[+] Mark Chest**.
2. Kijk naar een chest en rechtsklik, of gebruik de ingestelde marktoets.
3. Open Storage opnieuw en klik de gemarkeerde chest om naam, filters, prioriteit en actieve status in te stellen.

De marktoets kan ook direct tijdens het spelen worden gebruikt. **Nogmaals markeren van dezelfde chest deselecteert hem.** Unmark in de chesteditor verwijdert de markering eveneens. Single en double chests worden ondersteund; beide helften van een double chest verwijzen naar dezelfde markering. Alleen gewone/trapped chests met een standaard chestmenu worden gesorteerd; geen Ender Chests, barrels of modcontainers.

Gemarkeerde chests krijgen een groene glow-outline; uitgeschakelde chests worden oranje. Double chests krijgen een gezamenlijke outline. Deselecteren verwijdert de YunaGet-outline. Chest-glow en zichtbaarheid door muren zijn apart instelbaar; glow kan ook aan een toets worden gekoppeld. De algemene ESP-renderafstand geldt ook voor chests. Niet-geladen of verdwenen chests worden niet getekend.

### Filters en presets

Een filter is een door komma's gescheiden lijst met:

- Specifieke IDs: `minecraft:diamond,minecraft:diamond_block`.
- Tags die de clientregistry kent: `#minecraft:logs,#c:ingots`.
- Eigen categorieen: `@Wood`. Definieer die onder de Storage-instellingen.

Ontbrekende tags en categorieen matchen niets. Cyclische categorieen lopen niet oneindig door. De hoogste numerieke prioriteit wint onder specifieke filters. Een expliciete fallback-chest wordt alleen gekozen wanneer geen specifiek filter matcht en fallback aan staat. Een volle/onbereikbare specifieke chest laat de items in de inventory; er wordt niet zomaar naar een onjuiste fallback uitgeweken.

De chesteditor heeft presets **Diamonds, Ores, Building Blocks, Wood, Mob Drops, Food, Tools en Miscellaneous**. Een preset vervangt filters, prioriteit en fallbackinstelling; ingebouwde presets vullen ook de naam in. Miscellaneous is een expliciete fallback. Tagpresets werken alleen voor tags die de client kent en sommige lijsten zijn bewust voorbeelden, geen complete catalogus van alle moditems.

Je kunt eigen filterpresets opslaan, toepassen en verwijderen. Ze bevatten geen wereldpositie en worden gekopieerd bij toepassen, zodat chests onafhankelijk bewerkbaar blijven. Een preset bewaart de bewerkte filters en de actuele prioriteit/fallback van de chest. Maximaal 128 eigen presets, 256 chestmarkeringen en 512 filters per chest/preset.

### Server- en wereldscheiding

Markeringen zijn gekoppeld aan serveradres of lokaal savepad, wereldprofiel, dimensie en blockpositie. Chests uit andere scopes worden niet gebruikt of getoond.

Een normale multiplayer-client krijgt niet altijd een unieke ID voor meerdere werelden achter hetzelfde serveradres en dezelfde dimensie. Kies daarom onder Storage een eigen **wereldprofiel** per dergelijke wereld. De standaardwaarde is `default`. Wissel dit voordat je markeringen in een andere serverwereld gebruikt. Singleplayer gebruikt het lokale savepad automatisch.

### Sorteren en serverbevestiging

Nu sorteren start een enkele sorteerronde. Automatisch sorteren kan worden ingeschakeld bij een percentage bezette inventoryslots. AutoWalk naar chest is optioneel en standaard uit. Favoriete item-IDs, hotbar overslaan, minimale bewaaraantallen, maximale afstand en prioriteit blijven gelden. Itemdoelen kunnen optioneel ook als minimum worden behouden.

De sorter:

1. Bepaalt per actuele stack een filterbestemming.
2. Controleert wereld, afstand, chestblock en bereik; navigeert zo nodig met de gewone planner.
3. Opent met de gewone clientinteractie en wacht op een echt geopend chestmenu.
4. Valideert de containeridentiteit, 27/54 chestslots, alle 36 player-inventoryslots en een lege cursor. Inventoryslots worden herkend aan hun container en getContainerSlot(), niet aan hardgecodeerde menu-offsets.
5. Verplaatst een passende hele stack met normale QUICK_MOVE/shift-click.
6. Wacht op servergegevens die corresponderende bron- en bestemmingswijzigingen aantonen. Lokale voorspelling telt niet als bevestiging.
7. Als vanilla geen aparte wijzigingspackets verstuurt omdat de voorspelling klopt, sluit/heropent hij na een korte wachttijd dezelfde chest met normale interacties en controleert de verse serverinhoud. Hij klikt de verplaatsing niet nogmaals.
8. Gaat pas na bevestiging verder, sluit de chest en probeert de volgende bestemming.

Er wordt nooit bewust gedropt, een buiten-slot aangeklikt of een stack direct in een serverinventory geschreven. Alleen hele stacks worden verplaatst; een stack die de minimale bewaaraantallen zou onderschrijden blijft volledig bij de speler. Daardoor kan meer dan het ingestelde minimum achterblijven. Volle chests/ontbrekende paden worden overgeslagen. Bij timeout, onverwachte GUI, cursoritem, andere layout, ontbrekende bevestiging of handmatig klikken/toetsen in de sorteercontainer wordt veilig afgebroken en gepauzeerd. Een handmatige invoer die het sorteren annuleert wordt niet nog op de oude container uitgevoerd.

De client kan toegang tot protected chests pas vaststellen wanneer de server reageert. Een plugin die een andere maar identiek ogende standaard chest-GUI aanbiedt kan niet altijd van een echte chest worden onderscheiden; aangepaste containerplugins moeten apart getest worden. Containers worden tijdens verificatie mogelijk zichtbaar gesloten en heropend.

## Instellingen, architectuur en build

Oude keybinds en item-glowinstellingen blijven in `config/yunaget.properties`. Nieuwe instellingen, meerdere doelen, markeringen, categorieen en presets staan in `config/yunaget-v2.json`. Bij een eerste migratie wordt het oude geselecteerde item als doel meegenomen. Opslaan meldt fouten; bij een onleesbare JSON-config blijven de huidige/default instellingen behouden. Bewerken van bestanden doe je bij voorkeur met gestopte automatisering. Config opnieuw laden pauzeert de taken.

Belangrijkste modules: TaskManager, MiningTask (bestaande entrypoints behouden), TargetManager, InventoryTracker, AutoToolManager, NavigationManager, DropCollectorManager, WorldScanner, OreEspRenderer, ChestGlowRenderer, ChestManager, ChestFilterManager, AutoSorterManager, InventoryTransactionManager, Keybinds en YunaGetConfig. De gedeelde prioriteit is Sorter, Collector, Mining. Netwerkhandlers leveren alleen bevestigingsgegevens; wereldinteracties lopen op de Minecraft-clientthread. Het project heeft uitsluitend een client-entrypoint en clientmixins.

Bouwen met JDK 25 en de meegeleverde Gradle 9.8.1-wrapper:

```powershell
$env:JAVA_HOME = 'PAD/NAAR/JDK-25'
./gradlew.bat build
```

Op Linux/macOS: `./gradlew build`. Loom is vastgezet op 1.19.3. Uitvoer: `build/libs/yunaget-0.2.0.jar`. Er is ook een sources-JAR. De eerste build downloadt de afhankelijkheden; met gevulde cache werkt `--offline`.

## Validatie en resterende speltests

De build en JUnit-tests worden daadwerkelijk uitgevoerd. Tests staan onder `src/test/java` en behandelen exacte filters, tags, categoriecycli, fallback, prioriteit, stackaantallen, minima, voortgang, state-overgangen, serverbevestigingsvoorwaarden, onafhankelijkheid van presets en de Loader 0.19.5/client-only-metadata. HTML-testrapport: `build/reports/tests/test/index.html`.

Er zijn nog **geen Minecraft-speltests of Lunar Client-integratietests uitgevoerd**. Compileersucces en unit tests bewijzen geen correcte rendering, serverplugincompatibiliteit of volledige navigatieveiligheid. Controleer in een testwereld en vervolgens op de bedoelde server:

- Meerdere itemdoelen, oppakken/verbruiken, volle inventory, correcte tools/durability en stoppen.
- Collector rond obstakels, gevaar, ontbrekende routes en handmatige onderbreking.
- Alle glowopties, vanilla-glow, kleuren, zichtbaarheid en chunk-/wereldwissels.
- Single/double chest markeren, opnieuw deselecteren, Unmark, presets en herstart.
- Exacte/tag/categoryfilters, prioriteit, favorieten, hotbar, reserve, fallback en wereldprofielen.
- Sorteren met latency, volle/protected chests, cursoritems, onverwachte containers en handmatige onderbreking; bevestig geen verlies/duplicatie en controleer de echte serverinhoud.
- Loader 0.19.5 met Fabric API voor 26.3 en overige mods, inclusief Lunar indien gebruikt.